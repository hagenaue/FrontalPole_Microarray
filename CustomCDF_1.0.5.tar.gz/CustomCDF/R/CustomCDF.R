########cdfenv#######
createcdfenv <- function(object, cdffilename) {
	header <- readLines(con=cdffilename, n=6, ok=FALSE)
	cdfname=object@cdfName
	cdfenv <- .Call("createcdfenv", new.env(hash=TRUE), cdffilename, as.integer(nrow(object)), PACKAGE="CustomCDF")
	if (is.null(cdfenv)) stop()
	assign(cdfname, cdfenv, pos=1)
}
removeprobe <- function(object, xyMatrix=NULL, pbMatrix=NULL, minpbstsize=1, maxpbstsize=NULL, leftorright=c('left', 'right')) {
	oldenv <- getCdfInfo(object, verbose=TRUE)
	newenv <- new.env(hash=TRUE)
	rtn <- .Call("removeprobe", newenv, oldenv, as.integer(nrow(object)), xyMatrix, pbMatrix, as.integer(minpbstsize), as.integer(maxpbstsize), leftorright=='left', PACKAGE="CustomCDF")
	if (is.null(rtn)) stop()
	assign(object@cdfName, newenv, pos=1)
	i2xy <- function(i) {
		r=cbind((i-1)%% nrow(object) ,(i-1)%/% nrow(object) )
		colnames(r)=c("x","y")
		return(r)
	}
	list(removedprobe=data.frame(probeset=I(rtn[[1]]), index=rtn[[2]], pm=i2xy(rtn[[3]]), mm=i2xy(rtn[[4]])), removedprobeset=rtn[[5]])
}

read.affybatch.hybrid <- function(..., filenames = character(0), phenoData = new("AnnotatedDataFrame"),
		description = NULL, notes = "", compress = getOption("BioC")$affy$compress.cel,
		rm.mask = FALSE, rm.outliers = FALSE, rm.extra = FALSE, verbose = FALSE,
		sd = FALSE, cdfname = NULL, cdfmapping = NULL, minpbstsize=3) {
	auxnames <- unlist(as.list(substitute(list(...)))[-1])
	filenames <- .Primitive("c")(filenames, auxnames)
	if (length(filenames) == 0) stop("No file name given !")
	headers <- lapply(filenames, function(file) {.Call("ReadHeader", file, PACKAGE = "affyio")})
	celcdf <- sapply(headers, function(arr){arr[[1]]})
	origCdf <- unique(celcdf)
	if (length(origCdf) == 1) {
		if (is.null(cdfname) && !is.null(cdfmapping)) cdfname <- cdfmapping[[origCdf]]
		return(read.affybatch(filenames=filenames, phenoData=phenoData, description=description, notes=notes, compress=compress, rm.mask=rm.mask, rm.outliers=rm.outliers, rm.extra=rm.extra, verbose=verbose, sd=sd, cdfname=cdfname))
	}
	if (is.null(cdfmapping)) {
		cdfmapping <- origCdf
		names(cdfmapping) <- origCdf
	} else {
		if (length(cdfmapping) != length(unique(names(cdfmapping)))) stop(paste("names of parameter 'cdfmapping' is duplicated", sep=""))
		if (FALSE %in% (origCdf %in% names(cdfmapping))) stop(paste("names of parameter 'cdfmapping', is not consistent with celfile chip type (", paste(origCdf, collapse=", "), ")", sep=""))
		cdfmapping <- cdfmapping[origCdf]
	}
	if (is.null(cdfname)) {
		celrow <- sapply(headers, function(arr){arr[[2]][2]})
		cdfname <- cdfmapping[celcdf[[which.min(celrow)]]]
	} else if (cdfname %in% cdfmapping) 
		cdfname <- cdfmapping[match(cdfname, cdfmapping)]
	else 
		stop(paste("parameter cdfname should be one of (", paste(cdfmapping, collapse=", "), ")", sep=""))
	lAbatch <- vector('list', length(filenames))
	##try to read sample names form phenoData. if not there use CEL filenames
	pdata <- pData(phenoData)
	if(dim(pdata)[1] != length(filenames)) {
		##if empty pdata filename are samplenames
		warning("Incompatible phenoData object. Created a new one.\n")
		samplenames <- sub("^/?([^/]*/)*", "", unlist(filenames))
		pdata <- data.frame(sample=1:length(filenames), row.names=samplenames)
		phenoData <- new("AnnotatedDataFrame",data=pdata,varMetadata=data.frame(labelDescription="arbitrary numbering", row.names="sample"))
	} else 
		samplenames <- rownames(pdata)
	for (idx in 1:length(filenames)) {
		pdata <- data.frame(sample=1:1, row.names=samplenames[idx])
		pheTmp <- new("AnnotatedDataFrame",data=pdata,varMetadata=data.frame(labelDescription="arbitrary numbering", row.names="sample"))
		lAbatch[[idx]] <- read.affybatch(filenames=filenames[idx], phenoData=pheTmp,
			compress=compress, rm.mask=rm.mask, rm.outliers=rm.outliers, rm.extra=rm.extra,
			verbose=verbose, sd=sd)
	}
	getProbeInfo <- function(probename, verbose=FALSE) {
		probename <- paste(cleancdfname(probename, addcdf=FALSE), "probe", sep="")
		## First check to see if package is installed
		if (verbose)
			print(paste("Checking to see if package",probename, "is already installed"))
		if (length(find.package(probename, lib.loc=NULL, quiet=TRUE)) == 0) {
			print(paste("Library - package",probename,"not installed"))
			if (verbose)
				print(paste("Checking to see if your internet connection works ..."))
			if (testBioCConnection()) {
				## Check for file permissions
#				lib <- "/usr/local/lib64/R/library"
#				if (file.access(lib, mode=0) < 0) {
#					if (verbose) {
#						print(paste("Directory",lib,"does not seem to exist.\n",
#									"Please check your 'lib' parameter and try again"))
#						return(list("Bioconductor - lib does not exist"))
#					}
#				}
#				if (file.access(lib,mode=2) < 0) {
#					if (verbose) {
#						print(paste("You do not have write access to",lib,
#									"\nPlease check your permissions or provide",
#									"a different 'lib' parameter"))
#						return(list("Bioconductor - lib is not writeable"))
#					}
#				}
				source("http://bioconductor.org/biocLite.R")
				biocReposList <- biocinstallRepos()
				biocContribUrl <- sapply(biocReposList, contrib.url)
				biocPkgs <- available.packages(biocContribUrl)
				if (! probename %in% biocPkgs[, "Package"]) {
					if (verbose)
						print(paste("Environment",probename,
								"was not found in the Bioconductor",
								"repository."))
					return(list(paste("Bioconductor -",probename,"not available")))
				} else {
					install.packages(probename,
									 repos=biocReposList,
									 dependencies=TRUE)
				}
			} else {
				if (verbose)
					print(paste("The current operation could not access",
							"the Bioconductor repository. Please",
							"check your internet connection, and",
							"report further problems to",
							"bioconductor@stat.math.ethz.ch"))
				return(list("Bioconductor - could not connect"))
			}
		}
		## See if package is already loaded
		if (! probename %in% .packages()) {
			if (verbose) print(paste("Attempting to load package", probename))
			## Attempt to load the library requested
			do.call("library", list(probename, lib.loc=NULL, character.only=TRUE))
			## Check to see if it got loaded
			if (! probename %in% .packages()) {
				## package didn't get loaded
				if (verbose) print(paste("The package", probename, "could not be loaded"))
				return(list(paste("Library - package",probename,"is not loadable")))
			}
		}
		rtn <- get(probename, envir=as.environment(paste("package:", probename, sep="")))
		detach(pos=match(paste("package:", probename, sep=""), search()) )
		rtn 
	}
	lProbe <- lapply(cdfmapping, getProbeInfo, verbose=verbose)
	getCdfEnv <- function(cdfname, verbose=FALSE) {
		rtn <- getCdfInfo(new("AffyBatch", cdfName=cdfname), verbose=verbose)
		pkgname <- paste("package:", cleancdfname(cdfname), sep="")
		if (pkgname %in% search()) detach(pos=match(pkgname, search()) )
		rtn
	}
	lCdf <- lapply(cdfmapping, getCdfEnv, verbose=verbose)
	newenv <- new.env(hash=TRUE)
	signal <- .Call("read_affybatch_hybrid", newenv, lAbatch, lProbe, lCdf, sd, names(cdfname), integer(minpbstsize), PACKAGE="CustomCDF")
	if (length(newenv) == 0) stop('New cdf environment cannot be created, because of either too little shared probes, or too high parameter minpbstsize')
	assign(cdfname, newenv, pos=1)
	if (is.null(description)) {
		description <- new("MIAME")
		description@preprocessing$filenames <- filenames
		description@preprocessing$affyversion <- library(help=affy)$info[[2]][[2]][2]
	}
	colnames(signal[[1]]) <- samplenames
	if (sd) {
		colnames(signal[[2]]) <- samplenames
		ret <- new("AffyBatch", exprs=signal[[1]], se.exprs=signal[[2]], cdfName=cdfname[[1]], phenoData=phenoData, nrow=signal[[3]][1], ncol=signal[[3]][2], annotation=cleancdfname(cdfname, addcdf=FALSE), description=description, notes=notes)
	} else
		ret <- new("AffyBatch", exprs=signal[[1]], cdfName=cdfname[[1]], phenoData=phenoData, nrow=signal[[3]][1], ncol=signal[[3]][2], annotation=cleancdfname(cdfname, addcdf=FALSE), description=description, notes=notes)
	ret
}
