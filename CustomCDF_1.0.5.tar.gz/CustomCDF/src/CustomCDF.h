#include <R.h>
#include <Rdefines.h>
SEXP stop(const char *sFormat, ...);
SEXP getPbstDimNames(); //for createcdfenv and removeprobe
