#include <stdarg.h>
#include "CustomCDF.h"
SEXP stop(const char *sFormat, ...) {
	static int MSGLENGTH = 1048576;
	char sMsg[MSGLENGTH];
	va_list args;
	va_start(args, sFormat);
	vsnprintf(sMsg, MSGLENGTH, sFormat, args);
	REprintf(sMsg);
	va_end(args);
	return R_NilValue;
}

//for createcdfenv and removeprobe
SEXP getPbstDimNames() {
	SEXP dimnames, col;
	PROTECT(col = allocVector(STRSXP, 2));
	SET_STRING_ELT(col, 0, mkChar("pm"));
	SET_STRING_ELT(col, 1, mkChar("mm"));
	PROTECT(dimnames = allocVector(VECSXP, 2));
	SET_VECTOR_ELT(dimnames, 1, col);
	UNPROTECT(2);
	return dimnames;
}
