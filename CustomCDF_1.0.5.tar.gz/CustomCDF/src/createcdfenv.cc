#include <vector>
#include <string.h>
#include "CustomCDF.h"
using namespace std;
extern "C" {

SEXP createcdfenv(SEXP rCdfenv, SEXP rFile, SEXP rRowNum) {
	if (!isEnvironment(rCdfenv)) return stop("ERR-A001: Argument rCdfenv is not a environment variable\n");
	if (!isVector(rRowNum)) return stop("ERR-A002: Argument rRowNum is not a vector\n");
	if (!isInteger(rRowNum)) return stop("ERR-A003: Argument rRowNum is not integer\n");
	int iRowNum = INTEGER(rRowNum)[0];
	FILE *fCdf = fopen(CHAR(STRING_ELT(rFile, 0)), "rb");
	if (fCdf == NULL) return stop("ERR-A004: Cannot open file '%s'\n", CHAR(STRING_ELT(rFile, 0)));
	static int CDFFILELINE = 1048576;
	char sLine[CDFFILELINE];
	const static char *sHeader[] = {"[CDF]\r\n", "Version=GC3.0\r\n", "\r\n", "[Chip]\r\n"};
	for (int idx=0; idx<4; idx++) {
		if (fgets(sLine, CDFFILELINE, fCdf) == NULL) return stop("ERR-A005: End of file when reading the first 4 lines of cdf file\n");
		if (strcmp(sLine, sHeader[idx]) != 0) return stop("ERR-A006: It is not a cdf file based on the first 4 lines\n");
	}
	if (fgets(sLine, CDFFILELINE, fCdf) == NULL) return stop("ERR-A007: Cannot read the fifth line\n");
	if (fgets(sLine, CDFFILELINE, fCdf) == NULL) return stop("ERR-A008: Cannot read the sixth line\n");
	int iRow, iCol;
	if (sscanf(sLine, "Rows=%d", &iRow) != 1) return stop("ERR-A009: The sixth line is not 'Rows=NUM'\n");
	if (fgets(sLine, CDFFILELINE, fCdf) == NULL) return stop("ERR-A010: Cannot read the seventh line\n");
	if (sscanf(sLine, "Cols=%d", &iCol) != 1) return stop("ERR-A011: The seventh line is not 'Cols=NUM'\n");
	if (iRow != iCol) return stop("ERR-A012: Row/col number is not equal\n");
	if (iRow != iRowNum) return stop("ERR-A013: the cdf is not for the object, because row number are not the same\n");
	int iStatus = 0;
	char sName[CDFFILELINE];
	vector<int> vLocPm, vLocMm;
	SEXP dimnames = getPbstDimNames();
	while (fgets(sLine, CDFFILELINE, fCdf) != NULL) {
		if (iStatus == 0) {
		       	if (strncmp(sLine, "[Unit", 5) == 0 && strcmp(sLine + strlen(sLine)-9, "Block1]\r\n") == 0) {
				iStatus = 1;
				if (fgets(sLine, CDFFILELINE, fCdf) == NULL) return stop("ERR-A014: End of file when reading probeset name\n");
				strcpy(sName, sLine+5);
				sName[strlen(sName)-2] = 0;
				for (int idx=0; idx<6; idx++) if (fgets(sLine, CDFFILELINE, fCdf) == NULL) return stop("ERR-A015: End of file when reading probeset info\n");
				vLocPm.clear();
				vLocMm.clear();
			}
		} else if (iStatus == 1) {
			if (strcmp(sLine, "\r\n") == 0) {
				if (vLocPm.size() == 0) return stop("ERR-A016: Probeset '%s' has no probe\n", sName);
				if (vLocPm.size() != vLocMm.size() && vLocMm.size() > 0) return stop("ERR-A017: Probeset '%s' has different number of pm/mm probes\n", sName);
				iStatus = 0;
				SEXP val;
				PROTECT(val = allocMatrix(REALSXP, vLocPm.size(), 2));
				SET_DIMNAMES(val, dimnames);
				for (unsigned int idx=0; idx<vLocPm.size(); idx++) {
					REAL(val)[idx] = vLocPm[idx];
					REAL(val)[idx+vLocPm.size()] = vLocMm[idx];
				}
				defineVar(install(sName), val, rCdfenv);
				UNPROTECT(1);
				continue;
			}
//			char *sFields = sLine;
//			char *sToken = strsep(&sFields, "=");
			char *sFields = NULL;
			char *sToken = strtok_r(sLine, "=", &sFields);
			if (sFields == NULL) return stop("ERR-A018: Missing '=' for probe info of probeset '%s'\n", sName);
			int iFs = 0, iX, iY;
			char *sP, *sT = NULL;
			do {
//				sToken = strsep(&sFields, "\t");
				sToken = strtok_r(NULL, "\t", &sFields);
				char *sEnd;
				if (iFs == 0) {
					iX = strtol(sToken, &sEnd, 10);
					if (*sEnd != 0) return stop("ERR-A019: X coordinate of probeset '%s' is not an integer\n", sName);
					if (iX > iRow || iX <= 0) return stop("ERR-A020: X coordinate (%d) of probeset '%s' is not between 1 and %d\n", iX, sName, iRow);
				} else if (iFs == 1) {
					iY = strtol(sToken, &sEnd, 10);
					if (*sEnd != 0) return stop("ERR-A021: Y coordinate of probeset '%s' is not an integer\n", sName);
					if (iY > iRow || iY <= 0) return stop("ERR-A022: Y coordinate (%d) of probeset '%s' is not between 1 and %d\n", iY, sName, iRow);
				} else if (iFs == 8)
					sP = sToken;
				else if (iFs == 9) {
					sT = sToken;
					break;
				}
				iFs ++;
			} while (sFields != NULL);
			if (iFs != 9) return stop("ERR-A023: Missing field for probe info of probeset '%s'\n", sName);
			if (strcmp(sP, sT)) 
				vLocPm.push_back(iX+1+iY*iRow);
			else
				vLocMm.push_back(iX+1+iY*iRow);
		}
	}
	fclose(fCdf);
	return rCdfenv;
}

}
