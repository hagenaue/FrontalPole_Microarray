#include <set>
#include <vector>
#include <map>
#include <string>
#include "CustomCDF.h"
using namespace std;

class CommonProbe {
public:
	CommonProbe(int iChipCnt) {
		msLoc = new set<int>[iChipCnt];
	}
	~CommonProbe() {
		delete [] msLoc;
	}
	void insertProbe(int iChip, int iLoc) {
		msLoc[iChip].insert(iLoc);
	}
	bool getTrans(map<int, int*> *mapTrans, map<int, int> *mapPm2Mm, int iToChip, int iChipCnt) {
		for (int idxChip=0; idxChip<iChipCnt; idxChip++)
			if (msLoc[idxChip].size() == 0) return true;
		set<int>::iterator itFrom[iChipCnt];
		for (int idxChip=0; idxChip<iChipCnt; idxChip++) 
			itFrom[idxChip] = msLoc[idxChip].begin();
		for (set<int>::iterator itTo = msLoc[iToChip].begin(); itTo != msLoc[iToChip].end(); itTo++) {
			int *iTransPm = new int[iChipCnt];
			for (int idxChip=0; idxChip<iChipCnt; idxChip++) {
				iTransPm[idxChip] = *itFrom[idxChip];
				itFrom[idxChip]++;
				if (itFrom[idxChip] == msLoc[idxChip].end()) itFrom[idxChip] = msLoc[idxChip].begin();
			}
			if (!mapTrans->insert(pair<int, int*>(*itTo, iTransPm)).second) {
				delete [] iTransPm;
				return false;
			}
			int *iTransMm = new int[iChipCnt];
			for (int idxChip=0; idxChip<iChipCnt; idxChip++) {
				map<int, int>::iterator itMm = mapPm2Mm[idxChip].find(iTransPm[idxChip]);
				if (itMm == mapPm2Mm[idxChip].end()) {
					delete [] iTransMm;
					break;
				}
				iTransMm[idxChip] = itMm->second;
			}
/*
			if (!mapTrans->insert(pair<int, int*>(iTransMm[iToChip], iTransMm)).second) {
				delete [] iTransPm;
				return false;
			}
*/
			mapTrans->insert(pair<int, int*>(iTransMm[iToChip], iTransMm));
		}
		return true;
	}
private:
	set<int> *msLoc;
};
void fillNaN(double *dData, int iLen) {
	for (int idx=0; idx<iLen; idx++) dData[idx] = NA_REAL;
}

extern "C" {

SEXP read_affybatch_hybrid(SEXP rNewEnv, SEXP rAbatch, SEXP rProbe, SEXP rCdf, SEXP rSD, SEXP rToChip, SEXP rMinSize) {
	int iMinSize = INTEGER(rMinSize)[0];
	if (iMinSize <= 0) iMinSize = 1;
	bool bSD = LOGICAL(rSD)[0];
	//get common probes and their index
	map<string, pair<int, int> > mapChipDim;
	for (int idx=0; idx<LENGTH(rAbatch); idx++) {
		SEXP rAb = VECTOR_ELT(rAbatch, idx);
		const char *sChip = CHAR(STRING_ELT(GET_ATTR(rAb, install("cdfName")), 0));
		if (mapChipDim.find(sChip) == mapChipDim.end()) {
			int iNRow = INTEGER(GET_ATTR(rAb, install("nrow")))[0];
			int iNCol = INTEGER(GET_ATTR(rAb, install("ncol")))[0];
			mapChipDim.insert(pair<string, pair<int, int> >(sChip, pair<int, int>(iNRow, iNCol)));
		}
	}
	SEXP rChip = GET_NAMES(rProbe);
	int iChipCnt = LENGTH(rChip);
	map<string, CommonProbe*> mapCommonProbe;
	map<string, int> mapChipIdx;
	for (int idxChip=0; idxChip<iChipCnt; idxChip++) {
		const char *sChip = CHAR(STRING_ELT(rChip, idxChip));
		mapChipIdx.insert(pair<string, int>(sChip, idxChip));
		SEXP rObj = VECTOR_ELT(rProbe, idxChip);
		SEXP rSeq = VECTOR_ELT(rObj, 0);
		int *iX = INTEGER(VECTOR_ELT(rObj, 1));
		int *iY = INTEGER(VECTOR_ELT(rObj, 2));
//		int iNRow = mapChipDim.find(sChip)->second.first;
		int iNRow = mapChipDim.find(sChip)->second.second;
		for (int idx=0; idx<LENGTH(rSeq); idx++) {
			const char *sSeq = CHAR(STRING_ELT(rSeq, idx));
			map<string, CommonProbe*>::iterator iter = mapCommonProbe.find(sSeq);
			if (iter != mapCommonProbe.end()) 
				iter->second->insertProbe(idxChip, iX[idx]+iY[idx]*iNRow);
			else if (idxChip == 0) {
				iter = mapCommonProbe.insert(pair<string, CommonProbe*>(sSeq, new CommonProbe(iChipCnt))).first;
				iter->second->insertProbe(idxChip, iX[idx]+iY[idx]*iNRow);
			}
		}
	}
	//target chip
	int iToChip = 0;
	string sToChip(CHAR(STRING_ELT(rToChip, 0)));
	while (sToChip.compare(CHAR(STRING_ELT(rChip, iToChip))) != 0) 
		iToChip++;
	//get translation
	map<int, int> *mapPm2Mm = new map<int, int>[iChipCnt];
	for (int idxChip=0; idxChip<iChipCnt; idxChip++) {
		SEXP rEnv = VECTOR_ELT(rCdf, idxChip);
		SEXP pbstList = R_lsInternal(rEnv, Rboolean(true));
		int iLenPbstList = LENGTH(pbstList);
		vector<string> vPbst;
		for (int idx=0; idx<iLenPbstList; idx++) 
			vPbst.push_back(CHAR(STRING_ELT(pbstList, idx)));
		for (vector<string>::iterator itPbst = vPbst.begin(); itPbst != vPbst.end(); itPbst++) {
			SEXP pbList;
			PROTECT(pbList = AS_INTEGER(findVar(install(itPbst->c_str()), rEnv)));
			int iPbCnt = nrows(pbList);
			int *aiPbList = INTEGER(pbList);
			for (int idxPb=0; idxPb<iPbCnt; idxPb++) {
				int iMm = aiPbList[idxPb+iPbCnt];
				if (iMm > 0) {
					int iPm = aiPbList[idxPb];
					mapPm2Mm[idxChip].insert(pair<int, int>(iPm-1, iMm-1));
				}
			}
			UNPROTECT(1);
		}
	}
	map<int, int*> mapTrans;
	for (map<string, CommonProbe*>::iterator iter = mapCommonProbe.begin(); iter!= mapCommonProbe.end(); iter++)
		if (!iter->second->getTrans(&mapTrans, mapPm2Mm, iToChip, iChipCnt)) 
			return stop("ERR-E001: Probe package of the chip that you want to converted other chips to must be wrong\n");
	delete [] mapPm2Mm;
	for (map<string, CommonProbe*>::iterator iter = mapCommonProbe.begin(); iter!= mapCommonProbe.end(); iter++)
		delete iter->second;
	
	//generate new environment
	SEXP rOldEnv = VECTOR_ELT(rCdf, iToChip);
	SEXP pbstList = R_lsInternal(rOldEnv, Rboolean(true));
	int iLenPbstList = LENGTH(pbstList);
	vector<string> vPbst;
	for (int idx=0; idx<iLenPbstList; idx++) 
		vPbst.push_back(CHAR(STRING_ELT(pbstList, idx)));
	SEXP pbstDimName = getPbstDimNames();
	for (vector<string>::iterator itPbst = vPbst.begin(); itPbst != vPbst.end(); itPbst++) {
		const char *pbst = itPbst->c_str();
		SEXP rPbst = install(pbst);
		SEXP pbList;
		PROTECT(pbList = AS_INTEGER(findVar(rPbst, rOldEnv)));
		int iPbCnt = nrows(pbList);
		int *aiPbList = INTEGER(pbList);
		vector<pair<int, int> > vMatrix;
		for (int idxPb=0; idxPb<iPbCnt; idxPb++) {
			int iPm = aiPbList[idxPb];
			int iMm = aiPbList[idxPb+iPbCnt];
			if (mapTrans.find(iPm-1) != mapTrans.end())
				vMatrix.push_back(pair<int, int>(iPm, iMm));
		}
		UNPROTECT(1);
		if (vMatrix.size() >= (unsigned int)iMinSize) {
			SEXP val;
			PROTECT(val = allocMatrix(INTSXP, vMatrix.size(), 2));
			SET_DIMNAMES(val, pbstDimName);
			for (unsigned int idxPb=0; idxPb<vMatrix.size(); idxPb++) {
				INTEGER(val)[idxPb] = vMatrix[idxPb].first;
				INTEGER(val)[idxPb+vMatrix.size()] = vMatrix[idxPb].second;
			}
			defineVar(rPbst, val, rNewEnv);
			UNPROTECT(1);
		}
	}
	//merge all exprs of AffyBatch object
	map<string, pair<int,int> >::iterator itDim = mapChipDim.find(sToChip);
	int iNRowExprsAll = itDim->second.first * itDim->second.second;
	SEXP rExprsAll, rSeAll;
	PROTECT(rExprsAll = allocMatrix(REALSXP, iNRowExprsAll, LENGTH(rAbatch)));
	double *dExprsAll = REAL(rExprsAll);
	fillNaN(dExprsAll, iNRowExprsAll * LENGTH(rAbatch));
	double *dSeAll = NULL;
	if (bSD) {
		PROTECT(rSeAll = allocMatrix(REALSXP, iNRowExprsAll, LENGTH(rAbatch)));
		dSeAll = REAL(rSeAll);
		fillNaN(dSeAll, iNRowExprsAll * LENGTH(rAbatch));
	} else
		PROTECT(rSeAll = allocMatrix(REALSXP, 0, 0));
	for (int idxAb=0; idxAb<LENGTH(rAbatch); idxAb++) {
		SEXP rAb = VECTOR_ELT(rAbatch, idxAb);
		const char *sChip = CHAR(STRING_ELT(GET_ATTR(rAb, install("cdfName")), 0));
		int iLoc = mapChipIdx.find(sChip)->second;
		SEXP rAssayData = GET_ATTR(rAb, install("assayData"));
		double *dExprsOne = REAL(findVar(install("exprs"), rAssayData));
		for (map<int, int*>::iterator iter = mapTrans.begin(); iter != mapTrans.end(); iter++) 
			dExprsAll[idxAb*iNRowExprsAll+iter->first] = dExprsOne[iter->second[iLoc]];
		if (bSD) {
//			SEXP rSeOne = findVar(install("se.exprs"), rAssayData);
			double *dSeOne = REAL(findVar(install("se.exprs"), rAssayData));
			for (map<int, int*>::iterator iter = mapTrans.begin(); iter != mapTrans.end(); iter++) 
				dSeAll[idxAb*iNRowExprsAll+iter->first] = dSeOne[iter->second[iLoc]];
		}
	}
	//cleanup
	for (map<int, int*>::iterator iter = mapTrans.begin(); iter!= mapTrans.end(); iter++)
		delete [] iter->second;
	SEXP rDim, rRtn;
	PROTECT(rDim = allocVector(INTSXP, 2));
	INTEGER(rDim)[0] = itDim->second.first;
	INTEGER(rDim)[1] = itDim->second.second;
//	PROTECT(rDimName = allocVector(VECSXP, 2));
//	SET_DIMNAMES(rExprsAll, rDimName);
//	if (bSD) SET_DIMNAMES(rSeAll, rDimName);
	PROTECT(rRtn = allocVector(VECSXP, 3));
	SET_VECTOR_ELT(rRtn, 0, rExprsAll);
	SET_VECTOR_ELT(rRtn, 1, rSeAll);
	SET_VECTOR_ELT(rRtn, 2, rDim);
	UNPROTECT(4);
	return rRtn;
}

}
