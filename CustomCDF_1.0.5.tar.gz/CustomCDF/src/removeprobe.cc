#include <set>
#include <vector>
#include <string>
#include <map>
#include "CustomCDF.h"
using namespace std;
extern "C" {

SEXP removeprobe(SEXP rNewenv, SEXP rOldenv, SEXP rRowNum, SEXP xyMatrix, SEXP pbMatrix, SEXP rMinPbNum, SEXP rMaxPbNum, SEXP rLeft) {
	if (!isEnvironment(rNewenv)) return stop("ERR-B001: Argument rNewenv is not a environment variable\n");
	if (!isEnvironment(rOldenv)) return stop("ERR-B002: Argument rOldenv is not a environment variable\n");
	if (!isVector(rRowNum)) return stop("ERR-B003: Argument rRowNum is not a vector\n");
	if (!isInteger(rRowNum)) return stop("ERR-B004: Argument rRowNum is not integer\n");
	if (!isVector(rMinPbNum)) return stop("ERR-B005: Argument rMinPbNum is not a vector\n");
	if (!isInteger(rMinPbNum) || LENGTH(rMinPbNum) != 1) return stop("ERR-B006: Argument rMinPbNum is not an appropriate integer\n");
	if (!isVector(rMaxPbNum)) return stop("ERR-B007: Argument rMaxPbNum is not a vector\n");
	if (!isInteger(rMaxPbNum) || LENGTH(rMaxPbNum) > 1) return stop("ERR-B008: Argument rMaxPbNum is not an appropriate integer\n");
	if (!isVector(rLeft)) return stop("ERR-B007: Argument rLeft is not a vector\n");
	if (!isLogical(rLeft)) return stop("ERR-B008: Argument rLeft is not boolean type\n");
	int iMinPbNum = INTEGER(rMinPbNum)[0];
	int iMaxPbNum = -1;
	if (LENGTH(rMaxPbNum) == 1) iMaxPbNum =  INTEGER(rMaxPbNum)[0];
	bool bLeft = LOGICAL(rLeft)[0];
	set<int> setXY;
	if (!isNull(xyMatrix)) {
		if (!isVector(xyMatrix)) return stop("ERR-B009: Argument xyMatrix is not a matrix or vector\n");
		if (TYPEOF(xyMatrix) != 13 && TYPEOF(xyMatrix) != 14) return stop("ERR-B010: Argument xyMatrix is not numeric\n");
		int iRowNum = (INTEGER(rRowNum)[0]);
		int iNRows = nrows(xyMatrix);
		bool bDoubleXY = TYPEOF(xyMatrix) == 14;
		double *adXY = NULL;
		int *aiXY = NULL;
		if (bDoubleXY)
			adXY = REAL(xyMatrix);
		else
			aiXY = INTEGER(xyMatrix);
		for (int idx=0; idx<iNRows; idx++) {
			int iX, iY;
			if (bDoubleXY) {
				iX = (int)adXY[idx];
				iY = (int)adXY[idx+iNRows];
			} else {
				iX = aiXY[idx];
				iY = aiXY[idx+iNRows];
			}
			if (iX >= iRowNum || iX < 0)
				return stop("ERR-B011: coordiante X (%d) is not between 0 and %d", iX, iRowNum-1);
			if (iY >= iRowNum || iY < 0)
				return stop("ERR-B012: coordiante Y (%d) is not between 0 and %d", iY, iRowNum-1);
			setXY.insert(iY * iRowNum + iX + 1);
		}
	}
	map<string, set<int> > mapPb;
	if (!isNull(pbMatrix)) {
		if (!isVector(pbMatrix)) return stop("ERR-B013: Argument pbMatrix is not a vector\n");
		if (!isString(pbMatrix)) return stop("ERR-B014: Argument pbMatrix is not string\n");
		int iNRows = nrows(pbMatrix);
		for (int idx=0; idx<iNRows; idx++) {
			const char *pbst = CHAR(STRING_ELT(pbMatrix, idx));
			char *sEnd;
			int iIndex = strtol(CHAR(STRING_ELT(pbMatrix, idx+iNRows)), &sEnd, 10);
			if (*sEnd != 0) 
				return stop("ERR-B015: pbMatrix[%d,2] cannot be converted to integer\n", idx+1);
			map<string, set<int> >::iterator itPb = mapPb.find(pbst);
			if (itPb == mapPb.end()) 
				itPb = mapPb.insert(pair<string, set<int> >(pbst, set<int>())).first;
			itPb->second.insert(iIndex-1);
		}
	}
	SEXP pbstList = R_lsInternal(rOldenv, Rboolean(true));
	SEXP dimnames = getPbstDimNames();
	int iLenPbstList = LENGTH(pbstList);
	vector<string> vPbst;
	for (int idx=0; idx<iLenPbstList; idx++) 
		vPbst.push_back(CHAR(STRING_ELT(pbstList, idx)));
	vector<string> vRptPbst, vRptDelPbst;
	vector<int> vRptPos, vRptPm, vRptMm;
	for (vector<string>::iterator itPbst = vPbst.begin(); itPbst != vPbst.end(); itPbst++) {
		const char *pbst = itPbst->c_str();
		set<int> *setPb = NULL;
		map<string, set<int> >::iterator itPb = mapPb.find(pbst);
		if (itPb != mapPb.end()) setPb = & itPb->second;
		SEXP pbList;
		PROTECT(pbList = AS_INTEGER(findVar(install(pbst), rOldenv)));
		int iPbCntOld = nrows(pbList);
		int *aiPbList = INTEGER(pbList);
		vector<int> vLocPos, vLocPm, vLocMm;
		for (int idxPb=0; idxPb<iPbCntOld; idxPb++) {
			int iPm = aiPbList[idxPb];
			int iMm = aiPbList[idxPb+iPbCntOld];
			bool bInPbSet = setPb && setPb->find(idxPb) != setPb->end();
			if ( bInPbSet || setXY.find(iPm) != setXY.end() || setXY.find(iMm) != setXY.end()) {
				vRptPbst.push_back(pbst);
				vRptPos.push_back(idxPb+1);
				vRptPm.push_back(iPm);
				vRptMm.push_back(iMm);
				if (bInPbSet) setPb->erase(idxPb);
			} else {
				vLocPos.push_back(idxPb+1);
				vLocPm.push_back(iPm);
				vLocMm.push_back(iMm);
			}
		}
		UNPROTECT(1);
		if (setPb && setPb->size() > 0) {
			REprintf("Following probes don't exist");
			for (set<int>::iterator itPb=setPb->begin(); itPb != setPb->end(); itPb++)
				REprintf("%s %d\n", pbst, *itPb);
			return stop("The probe list is wrong\n");
		}
		if (vLocPos.size() >= (unsigned int)iMinPbNum && vLocPos.size() > 0) {
			unsigned int iFrom = 0;
			unsigned int iTo = vLocPos.size();
			if (iTo > (unsigned int)iMaxPbNum && iMaxPbNum != -1) {
				if (bLeft)
					iTo = iMaxPbNum;
				else
					iFrom = iTo - iMaxPbNum;
			}
			int iSize = iTo - iFrom;
			SEXP val;
			PROTECT(val = allocMatrix(INTSXP, iSize, 2));
			SET_DIMNAMES(val, dimnames);
			for (unsigned int idxPb=0; idxPb<vLocPos.size(); idxPb++) {
				if (idxPb >= iFrom && idxPb < iTo) {
					INTEGER(val)[idxPb-iFrom] = vLocPm[idxPb];
					INTEGER(val)[idxPb-iFrom+iSize] = vLocMm[idxPb];
				} else {
					vRptPbst.push_back(pbst);
					vRptPos.push_back(vLocPos[idxPb]);
					vRptPm.push_back(vLocPm[idxPb]);
					vRptMm.push_back(vLocMm[idxPb]);
				}
			}
			defineVar(install(pbst), val, rNewenv);
			UNPROTECT(1);
		} else {
			vRptDelPbst.push_back(pbst);
			for (unsigned int idxPb=0; idxPb<vLocPos.size(); idxPb++) {
				vRptPbst.push_back(pbst);
				vRptPos.push_back(vLocPos[idxPb]);
				vRptPm.push_back(vLocPm[idxPb]);
				vRptMm.push_back(vLocMm[idxPb]);
			}
		}
		if (itPb != mapPb.end()) mapPb.erase(pbst);
	}
	if (mapPb.size() > 0) {
		REprintf("following probesets don't exist\n");
		for (map<string, set<int> >::iterator itPb=mapPb.begin(); itPb != mapPb.end(); itPb++)
			REprintf("%s\n", itPb->first.c_str());
		return stop("The probeset list is wrong\n");
	}
	int iRptLen = vRptPbst.size();
	SEXP rRptPbst, rRptPos, rRptPm, rRptMm;
	PROTECT(rRptPbst = allocVector(STRSXP, iRptLen));
	PROTECT(rRptPos = allocVector(INTSXP, iRptLen));
	PROTECT(rRptPm = allocVector(INTSXP, iRptLen));
	PROTECT(rRptMm = allocVector(INTSXP, iRptLen));
	for (int idx=0; idx<iRptLen; idx++) {
		SET_STRING_ELT(rRptPbst, idx, mkChar(vRptPbst[idx].c_str()));
		INTEGER(rRptPos)[idx] = vRptPos[idx];
		INTEGER(rRptPm)[idx] = vRptPm[idx];
		INTEGER(rRptMm)[idx] = vRptMm[idx];
	}
	SEXP rRptDelPbst;
	PROTECT(rRptDelPbst = allocVector(STRSXP, vRptDelPbst.size()));
	for (unsigned int idx=0; idx<vRptDelPbst.size(); idx++)
		SET_STRING_ELT(rRptDelPbst, idx, mkChar(vRptDelPbst[idx].c_str()));
	SEXP rRtn;
	PROTECT(rRtn = allocVector(VECSXP, 5));
	SET_VECTOR_ELT(rRtn, 0, rRptPbst);
	SET_VECTOR_ELT(rRtn, 1, rRptPos);
	SET_VECTOR_ELT(rRtn, 2, rRptPm);
	SET_VECTOR_ELT(rRtn, 3, rRptMm);
	SET_VECTOR_ELT(rRtn, 4, rRptDelPbst);
	UNPROTECT(6);
	return rRtn;
}


}
